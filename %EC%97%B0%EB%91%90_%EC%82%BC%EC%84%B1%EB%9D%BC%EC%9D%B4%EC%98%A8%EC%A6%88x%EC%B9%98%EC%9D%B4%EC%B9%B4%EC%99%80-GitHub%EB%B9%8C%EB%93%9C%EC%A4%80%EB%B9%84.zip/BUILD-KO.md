# 삼성라이온즈 × 치이카와 카카오톡 테마 APK 빌드 안내

이 프로젝트는 GitHub Actions에서 APK를 빌드하도록 준비되어 있습니다.

## 휴대폰에서 진행
1. GitHub 계정으로 로그인하고 새 저장소(repository)를 만듭니다. 저장소 이름 예: `samsung-lions-chiikawa-theme`. 처음에는 Private으로 만들어도 됩니다.
2. 이 ZIP의 압축을 풀고, 압축 안의 파일과 폴더 전체를 저장소 최상위(root)에 올립니다. `.github/workflows/build-apk.yml`도 반드시 포함되어야 합니다.
3. 업로드 후 저장소의 **Actions** 탭을 엽니다. `Build Android APK` 작업을 선택합니다.
4. `Run workflow`가 보이면 눌러 실행합니다. 파일 업로드로 자동 실행된 경우에는 진행 중인 실행을 열면 됩니다.
5. 작업이 초록색 체크로 끝나면 실행 페이지 아래 **Artifacts**에서 `samsung-lions-chiikawa-theme-apk`를 눌러 다운로드합니다.
6. 내려받은 ZIP을 휴대폰에서 풀고 안의 APK를 설치합니다. Android가 설치 확인을 표시하면 내용을 확인한 뒤 진행하세요.

## 참고
- GitHub 비밀번호, 개인 액세스 토큰(PAT), 인증 코드를 누구에게도 보내지 마세요.
- 첫 빌드가 실패하면 Actions 실행 화면의 빨간 오류 부분을 캡처해 공유하면 원인을 확인할 수 있습니다.
- 이 설정은 GitHub의 공식 Actions 실행 환경에서 빌드합니다. 실제 빌드 성공은 Actions 실행 후 확인해야 합니다.
